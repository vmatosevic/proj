typedef struct {
	int id;
	char ime[20];
	char prezime[20];
	char adresa[40];
	int brojMob;
	int brojFilm;
}CLAN;