#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "data_type.h"


static int brojac = 0;

void NoviKor() {

	FILE* pF = fopen("clanovi.bin", "rb+");
	if (pF == NULL) {
		perror("Dodavanje studenta u datoteke clanovi.bin");
		exit(EXIT_FAILURE);
	}
	fread(&brojac, sizeof(int), 1, pF);

	CLAN temp = { 0 };
	temp.id = brojac;

	printf("Unesite ime clana!\n");
	scanf("%s", &temp.ime);
	printf("Unesite prezime clana!\n");

	scanf("%s", &temp.prezime);
	printf("Unesite adresu clana!\n");

	scanf("%s", &temp.adresa);
	printf("Unesite broj mobitela clana!\n");

	scanf("%d", &temp.brojMob);
	printf("Unesite broj podignutih filmova clana!\n");

	scanf("%d", &temp.brojFilm);



	fseek(pF, sizeof(CLAN) * brojac + sizeof(int), SEEK_SET);
	fwrite(&temp, sizeof(CLAN), 1, pF);
	rewind(pF);
	brojac++;
	fwrite(&brojac, sizeof(int), 1, pF);
	fclose(pF);

}

void* ucitavanje() {
	FILE* pF = fopen("clanovi.bin", "rb");
	if (pF == NULL) {
		perror("Ucitavanje clanova iz datoteke clanovi.bin");
		return NULL;
	}

	fread(&brojac, sizeof(int), 1, pF);


	CLAN* polje = (CLAN*)calloc(brojac, sizeof(CLAN));
	if (polje == NULL) {
		perror("Zauzimanje memorije za studente");
		return NULL;
	}

	fread(polje, sizeof(CLAN), brojac, pF);

	return polje;
}

void ispis(const CLAN* const polje) {
	if (polje == NULL) {
		printf("Polje studenata je prazno!\n");
		return;
	}
	int i;
	for (i = 0; i < brojac; i++)
	{
		printf("Clan\nID: %d\nime: %s\nprezime: %s\nadresa: %s\nbroj mobitela: %d\nbroj podignutih filmova: %d\n",

			(polje + i)->id,
			(polje + i)->ime,
			(polje + i)->prezime,
			(polje + i)->adresa,
			(polje + i)->brojMob,
			(polje + i)->brojFilm
		);
	}
}


void pretrazivanje(CLAN* const polje) {
	if (polje == NULL) {
		printf("Polje clanova je prazno!\n");
		return;
	}
	int i;
	int trazenid;
	printf("Unesite id clana.\n");

	scanf("%d", &trazenid);
	for (i = 0; i < brojac; i++)
	{

		if (trazenid == (polje + i)->id) {
			printf("Clan je pronaden!\n");
			printf("Clan\nID: %d\nime: %s\nprezime: %s\nadresa: %s\nbroj mobitela: %d\nbroj podignutih filmova: %d\n",

				(polje + i)->id,
				(polje + i)->ime,
				(polje + i)->prezime,
				(polje + i)->adresa,
				(polje + i)->brojMob,
				(polje + i)->brojFilm
			);
		}
	}

}


int izlazIzPrograma(CLAN* poljeStudenata) {
	char c[10] = "";
	char s[] = "ne";
	free(poljeStudenata);
	printf("Da li ste sigurni kako zelite zavrsiti program?\nda/ne\n");
	scanf("%s", c);
	if (!strcmp(c, s)) {

		return 1;
	}
	else {

		return 0;
	}



}


}