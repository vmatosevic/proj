int izbornik();
void NoviKor();
void* ucitavanje();
void ispis(const CLAN* const);
void pretrazivanje(CLAN* const polje);
int izlazIzPrograma(CLAN* poljeStudenata);